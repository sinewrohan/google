package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GoogleHomePageObjects {

	public WebDriver driver;
	
	private By searchBox= By.xpath("//input[@name='q']");
	 public GoogleHomePageObjects(WebDriver driver) {
		 this.driver=driver;
		// TODO Auto-generated constructor stub
	}
	public WebElement getSearchBox(){
		 return driver.findElement(searchBox);
	 }
	
}
