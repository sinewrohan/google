package utility;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

import pageObjects.GoogleHomePageObjects;
import resources.BaseTest;

import resources.dataDriven;

public class GoogleHomePageTest extends BaseTest {

	public WebDriver driver;

	@BeforeTest
	public void initialiseDriverTest() throws IOException, InterruptedException {
		driver = initialiseDriver();
		driver.get(prop.getProperty("url"));
		Thread.sleep(2000);
	}

	@Test
	public void googleSearchBoxTest() throws InterruptedException, IOException {
		GoogleHomePageObjects gh = new GoogleHomePageObjects(driver);
		
		dataDriven d = new dataDriven();
		System.out.println(System.getProperty("user.dir"));
		ArrayList<String> data = d.getData("data");
		gh.getSearchBox().sendKeys(data.get(1));
		System.out.println(data.get(0));
		gh.getSearchBox().sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		gh.getSearchBox().clear();
		Thread.sleep(2000);
		gh.getSearchBox().sendKeys(data.get(2));
		Thread.sleep(2000);
		gh.getSearchBox().sendKeys(Keys.ENTER);

	}

}
